#include "Adresat.h"

using namespace std;

Adresat::Adresat()
{
    int id = 0;
    int idUzytkownika = 0;
    string imie = "";
    string nazwisko = "";
    string numerTelefonu = "";
    string email = "";
    string adres = "";
}

Adresat::~Adresat() {;}

int Adresat::pobierzId()
{
    return id;
}

string Adresat::pobierzImie()
{
    return imie;
}

string Adresat::pobierzNazwisko()
{
    return nazwisko;
}

string Adresat::pobierzNumerTelefonu()
{
    return numerTelefonu;
}

string Adresat::pobierzEmail()
{
    return email;
}

string Adresat::pobierzAdres()
{
    return adres;
}

void Adresat::ustawId(int id)
{
    this->id = id;
}

void Adresat::ustawImie(string imie)
{
    this->imie = imie;
}

void Adresat::ustawNazwisko(string nazwisko)
{
    this->nazwisko = nazwisko;
}

void Adresat::ustawNumerTelefonu(string numerTelefonu)
{
    this->numerTelefonu = numerTelefonu;
}

void Adresat::ustawEmail(string email)
{
    this->email = email;
}

void Adresat::ustawAdres(string adres)
{
    this->adres = adres;
}
