#ifndef ADRESAT_H
#define ADRESAT_H

#include <iostream>

using namespace std;

class Adresat
{
public:
    int id;
    int idUzytkownika ;
    string imie;
    string nazwisko ;
    string numerTelefonu ;
    string email ;
    string adres ;

public:

    Adresat();
    virtual ~Adresat();

    int pobierzId();
    string pobierzImie();
    string pobierzNazwisko();
    string pobierzNumerTelefonu();
    string pobierzEmail();
    string pobierzAdres();

    void ustawId(int id );
    void ustawImie(string imie);
    void ustawNazwisko(string nazwisko);
    void ustawNumerTelefonu(string numerTelefonu);
    void ustawEmail(string email);
    void ustawAdres(string adres);
};

#endif
