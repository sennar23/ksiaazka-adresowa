#ifndef KSIAZKAADRESOWA_H
#define KSIAZKAADRESOWA_H

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <windows.h>
#include <vector>
#include <algorithm>

#include "PlikAdresaci.h"
#include "Adresat.h"
#include "Uzytkownicy.h"

using namespace std;

class KsiazkaAdresowa
{
private:
    PlikAdresaci plikAdresaci;
    vector<Adresat> adresaci;
    int idOstatniegoAdresata ;
    int idUsunietegoAdresata ;

public:
    KsiazkaAdresowa();
    virtual ~KsiazkaAdresowa();

    int idZalogowanegoUzytkownika;
    void wyswietlDaneAdresata(Adresat adresat);
    int dodajAdresata(int idZalogowanegoUzytkownika);
    int wczytajAdresatowZalogowanegoUzytkownikaZPliku(vector <Adresat> &adresaci, int idZalogowanegoUzytkownika);
    int dodajAdresata(vector <Adresat> &adresaci, int idZalogowanegoUzytkownika, int idOstatniegoAdresata);
    void wyszukajAdresatowPoImieniu();
    void wyszukajAdresatowPoNazwisku();
    void wyswietlWszystkichAdresatow();
    int usunAdresata();
    void edytujAdresata();

    friend int wczytajAdresatowZalogowanegoUzytkownikaZPliku(vector <Adresat> &adresaci,int idZalogowanegoUzytkownika);

private:
    string zamienPierwszaLitereNaDuzaAPozostaleNaMale(string tekst);
    Adresat podajDaneNowegoAdresata(int idZalogowanegoUzytkownika, int idOstatniegoAdresata);
    void wyswietlIloscWyszukanychAdresatow(int iloscAdresatow);
    int podajIdWybranegoAdresata();
    int zwrocNumerLiniiSzukanegoAdresata(int idAdresata);
    char wybierzOpcjeZMenuEdycja();
    void zaktualizujDaneEdytowanegoAdresata(Adresat adresat, int idEdytowanegoAdresata);
};
#endif
