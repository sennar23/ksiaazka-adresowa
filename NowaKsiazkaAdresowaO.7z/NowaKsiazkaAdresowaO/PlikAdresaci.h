#ifndef PLIKADRESACI_H
#define PLIKADRESACI_H

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <vector>

#include "Adresat.h"
#include "Plik.h"
#include "Uzytkownicy.h"

using namespace std;

class PlikAdresaci : private Plik
{
public:
    string nazwaPlikuZAdresatami;
    string nazwaTymczasowegoPlikuZAdresatami;
public:
    PlikAdresaci();
    virtual ~PlikAdresaci();

    void dopiszAdresataDoPliku(Adresat adresat);
    int pobierzZPlikuIdOstatniegoAdresata();
    int pobierzIdAdresataZDanychOddzielonychPionowymiKreskami(string daneJednegoAdresataOddzielonePionowymiKreskami);
    Adresat pobierzDaneAdresata(string daneAdresataOddzielonePionowymiKreskami);
    void usunWybranaLinieWPliku(int numerUsuwanejLinii);
    string zamienDaneAdresataNaLinieZDanymiOddzielonaPionowymiKreskami(Adresat adresat);
    void edytujWybranaLinieWPliku(int numerEdytowanejLinii, string liniaZDanymiAdresataOddzielonePionowymiKreskami);
    int wczytajAdresatowZalogowanegoUzytkownikaZPliku(vector <Adresat> &adresaci,int idZalogowanegoUzytkownika);

private:
    string konwerjsaIntNaString(int liczba);
    int konwersjaStringNaInt(string liczba);
    string pobierzLiczbe(string tekst, int pozycjaZnaku);
    void usunOdczytywanyPlik(string nazwaPlikuZRozszerzeniem);
    void zmienNazweTymczasowegoPlikuNaNazweOdczytywanegoPliku(string nazwaTymczasowegoPlikuZRozszerzeniem, string nazwaPlikuZRozszerzeniem);
    int pobierzIdUzytkownikaZDanychOddzielonychPionowymiKreskami(string daneJednegoAdresataOddzielonePionowymiKreskami);
};

#endif
