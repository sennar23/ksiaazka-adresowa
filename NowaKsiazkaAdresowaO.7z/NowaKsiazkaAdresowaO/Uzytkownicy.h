#ifndef UZYTKOWNICY_H
#define UZYTKOWNICY_H

#include <iostream>
#include <cstdlib>
#include <vector>
#include "Uzytkownik.h"
#include "PlikUzytkownicy.h"
#include "PlikAdresaci.h"
#include "KsiazkaAdresowa.h"

using namespace std;

class Uzytkownicy
{
private:
    PlikUzytkownicy plikUzytkownicy;

public:
    Uzytkownicy();
    virtual ~Uzytkownicy();

        vector<Uzytkownik> uzytkownicy;
    int idZalogowanegoUzytkownika;
    int pobierzIdZalogowanegoUzytkownika();
    void logowanieUzytkownika();
    void rejestracjaUzytkownika();
    void zmianaHaslaZalogowanegoUzytkownika();
    void wyloguj();

    friend int wczytajAdresatowZalogowanegoUzytkownikaZPliku(vector <Adresat> &adresaci,int idZalogowanegoUzytkownika);


private:
    Uzytkownik podajDaneNowegoUzytkownika();
    int pobierzIdNowegoUzytkownika();
    bool czyIstniejeLogin(string login);
    string wprowadzHaslo();
};

#endif
